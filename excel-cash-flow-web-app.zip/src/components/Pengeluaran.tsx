import { useState } from "react";
import { MONTHS } from "../types";

interface PengeluaranProps {
  DETAIL_KATEGORI: string[];
  getPengeluaran: (kategori: string, bulan: number) => number;
  getTotalSaldoKategori: (i: number) => number;
  getSisaSaldo: (i: number) => number;
  getTotalSaldoKeseluruhan: () => number;
  updatePengeluaran: (kategori: string, bulan: number, jumlah: number) => void;
  getTotalPengeluaranKategori: (kategori: string) => number;
}

function formatRupiah(amount: number) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(amount);
}

export default function Pengeluaran({
  DETAIL_KATEGORI,
  getPengeluaran,
  getTotalSaldoKategori,
  getSisaSaldo,
  getTotalSaldoKeseluruhan,
  updatePengeluaran,
  getTotalPengeluaranKategori,
}: PengeluaranProps) {
  const [editCell, setEditCell] = useState<{ kategori: string; bulan: number } | null>(null);
  const [editValue, setEditValue] = useState("");

  const handleCellClick = (kategori: string, bulan: number) => {
    const val = getPengeluaran(kategori, bulan);
    setEditCell({ kategori, bulan });
    setEditValue(val > 0 ? String(val) : "");
  };

  const handleSave = () => {
    if (!editCell) return;
    const jumlah = parseInt(editValue) || 0;
    updatePengeluaran(editCell.kategori, editCell.bulan, jumlah);
    setEditCell(null);
  };

  const categoryConfig = [
    { color: "text-blue-600", bg: "bg-blue-50", dotColor: "bg-blue-500" },
    { color: "text-purple-600", bg: "bg-purple-50", dotColor: "bg-purple-500" },
    { color: "text-emerald-600", bg: "bg-emerald-50", dotColor: "bg-emerald-500" },
  ];

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Pengeluaran & Sisa Saldo</h2>
        <p className="text-gray-500 text-sm mt-1">Catat pengeluaran dan lihat sisa saldo setiap kategori</p>
      </div>

      {/* Saldo Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {DETAIL_KATEGORI.map((kat, i) => {
          const masuk = getTotalSaldoKategori(i);
          const keluar = getTotalPengeluaranKategori(kat);
          const sisa = getSisaSaldo(i);
          const pct = masuk > 0 ? Math.round((sisa / masuk) * 100) : 100;
          return (
            <div key={kat} className={`rounded-2xl p-4 ${categoryConfig[i].bg} border border-gray-100`}>
              <div className="flex items-center gap-2 mb-3">
                <span className={`w-2 h-2 rounded-full ${categoryConfig[i].dotColor}`}></span>
                <span className={`text-sm font-semibold ${categoryConfig[i].color}`}>{kat}</span>
              </div>
              <div className="space-y-1 text-xs text-gray-600 mb-3">
                <div className="flex justify-between">
                  <span>Total Saldo</span>
                  <span className="font-semibold text-gray-700">{formatRupiah(masuk)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Pengeluaran</span>
                  <span className="font-semibold text-red-500">-{formatRupiah(keluar)}</span>
                </div>
                <div className="border-t border-gray-200 pt-1 flex justify-between">
                  <span className="font-semibold">Sisa</span>
                  <span className={`font-bold ${categoryConfig[i].color}`}>{formatRupiah(sisa)}</span>
                </div>
              </div>
              <div className="bg-white rounded-full h-2 overflow-hidden">
                <div
                  className={`h-full ${categoryConfig[i].dotColor} rounded-full transition-all`}
                  style={{ width: `${pct}%` }}
                />
              </div>
              <p className="text-xs text-gray-400 mt-1">{pct}% sisa</p>
            </div>
          );
        })}
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-semibold text-gray-700">Rincian Pengeluaran</h3>
          <span className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded-full">
            Klik sel untuk edit
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-rose-700 to-rose-600 text-white">
                <th className="text-left px-4 py-3.5 font-semibold sticky left-0 bg-rose-700 min-w-[130px]">
                  Kas Teknisi
                </th>
                {MONTHS.map((month) => (
                  <th key={month} className="px-3 py-3.5 font-semibold text-center min-w-[100px]">
                    {month}
                  </th>
                ))}
                <th className="px-4 py-3.5 font-semibold text-center min-w-[120px] bg-rose-800">
                  Sisa Saldo
                </th>
              </tr>
            </thead>
            <tbody>
              {DETAIL_KATEGORI.map((kat, katIdx) => (
                <tr key={kat} className={katIdx % 2 === 0 ? "bg-white" : "bg-gray-50/60"}>
                  <td className={`px-4 py-3 font-medium sticky left-0 border-r border-gray-100 ${katIdx % 2 === 0 ? "bg-white" : "bg-gray-50"}`}>
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${categoryConfig[katIdx].dotColor}`}></span>
                      <span className={categoryConfig[katIdx].color}>{kat}</span>
                    </div>
                  </td>
                  {MONTHS.map((_, bulanIdx) => {
                    const val = getPengeluaran(kat, bulanIdx);
                    const isEditing = editCell?.kategori === kat && editCell?.bulan === bulanIdx;
                    return (
                      <td
                        key={bulanIdx}
                        className="px-2 py-3 text-center border-r border-gray-50 cursor-pointer hover:bg-rose-50 transition-colors"
                        onClick={() => handleCellClick(kat, bulanIdx)}
                      >
                        {isEditing ? (
                          <input
                            autoFocus
                            type="number"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            onBlur={handleSave}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") handleSave();
                              if (e.key === "Escape") setEditCell(null);
                            }}
                            className="w-20 text-center border border-rose-400 rounded-lg px-1 py-0.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400"
                          />
                        ) : val > 0 ? (
                          <span className="text-red-600 font-medium">{formatRupiah(val)}</span>
                        ) : (
                          <span className="text-gray-300">Rp0</span>
                        )}
                      </td>
                    );
                  })}
                  <td className="px-4 py-3 text-center bg-gradient-to-r from-green-50 to-emerald-50">
                    <span className="font-bold text-emerald-700">{formatRupiah(getSisaSaldo(katIdx))}</span>
                  </td>
                </tr>
              ))}
            </tbody>
            {/* Total Footer */}
            <tfoot>
              <tr className="bg-gradient-to-r from-green-700 to-emerald-600 text-white">
                <td colSpan={MONTHS.length + 1} className="px-4 py-3.5 text-center font-bold text-lg sticky left-0">
                  <span className="bg-white/10 px-4 py-1 rounded-full">
                    🏦 Total Saldo Kas Teknisi
                  </span>
                </td>
                <td className="px-4 py-3.5 text-center font-bold text-xl">
                  <span className="text-yellow-300">{formatRupiah(getTotalSaldoKeseluruhan())}</span>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      <p className="text-xs text-gray-400 text-center">
        💡 Klik sel pengeluaran untuk mengubah nilai · Sisa saldo dihitung otomatis
      </p>
    </div>
  );
}
