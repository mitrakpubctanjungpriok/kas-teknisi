import { MONTHS } from "../types";

interface DashboardProps {
  teknisiList: { id: string; nama: string }[];
  getTotalBulanan: (bulan: number) => number;
  getTotalSaldoKategori: (i: number) => number;
  getSisaSaldo: (i: number) => number;
  getTotalSaldoKeseluruhan: () => number;
  DETAIL_KATEGORI: string[];
  getDetailKas?: (i: number, bulan: number) => number;
}

function formatRupiah(amount: number) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(amount);
}

export default function Dashboard({
  teknisiList,
  getTotalBulanan,
  getTotalSaldoKategori,
  getSisaSaldo,
  getTotalSaldoKeseluruhan,
  DETAIL_KATEGORI,
}: DashboardProps) {
  const totalKeseluruhan = getTotalSaldoKeseluruhan();
  const totalKasMasuk = MONTHS.reduce((sum, _, i) => sum + getTotalBulanan(i), 0);

  const categoryColors = [
    { bg: "from-blue-500 to-blue-600", light: "bg-blue-50", text: "text-blue-700", border: "border-blue-200" },
    { bg: "from-purple-500 to-purple-600", light: "bg-purple-50", text: "text-purple-700", border: "border-purple-200" },
    { bg: "from-emerald-500 to-emerald-600", light: "bg-emerald-50", text: "text-emerald-700", border: "border-emerald-200" },
  ];

  // Chart data - last 6 months with data
  const chartMonths = MONTHS.slice(0, 6);
  const maxTotal = Math.max(...chartMonths.map((_, i) => getTotalBulanan(i)), 1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Dashboard</h2>
        <p className="text-gray-500 text-sm mt-1">Ringkasan keuangan kas teknisi tahun ini</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Saldo */}
        <div className="bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl p-5 text-white shadow-lg shadow-blue-200 col-span-1 md:col-span-2 lg:col-span-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-blue-200 text-sm font-medium">Total Saldo</p>
              <p className="text-2xl font-bold mt-1">{formatRupiah(totalKeseluruhan)}</p>
              <p className="text-blue-200 text-xs mt-2">Keseluruhan kas teknisi</p>
            </div>
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>

        {/* Total Kas Masuk */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">Total Kas Masuk</p>
              <p className="text-xl font-bold text-gray-800 mt-1">{formatRupiah(totalKasMasuk)}</p>
              <p className="text-gray-400 text-xs mt-2">Seluruh iuran teknisi</p>
            </div>
            <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 11l5-5m0 0l5 5m-5-5v12" />
              </svg>
            </div>
          </div>
        </div>

        {/* Jumlah Teknisi */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">Jumlah Teknisi</p>
              <p className="text-xl font-bold text-gray-800 mt-1">{teknisiList.length} Orang</p>
              <p className="text-gray-400 text-xs mt-2">Anggota aktif</p>
            </div>
            <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
          </div>
        </div>

        {/* Bulan Aktif */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">Bulan Aktif</p>
              <p className="text-xl font-bold text-gray-800 mt-1">
                {MONTHS.filter((_, i) => getTotalBulanan(i) > 0).length} Bulan
              </p>
              <p className="text-gray-400 text-xs mt-2">Ada pemasukan</p>
            </div>
            <div className="w-10 h-10 bg-yellow-100 rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Category Cards + Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Breakdown */}
        <div className="lg:col-span-1 space-y-4">
          <h3 className="font-semibold text-gray-700">Distribusi Kas</h3>
          {DETAIL_KATEGORI.map((kat, i) => {
            const saldo = getTotalSaldoKategori(i);
            const sisa = getSisaSaldo(i);
            const pct = totalKasMasuk > 0 ? Math.round((saldo / totalKasMasuk) * 100) : 0;
            return (
              <div key={kat} className={`rounded-2xl p-4 border ${categoryColors[i].border} ${categoryColors[i].light}`}>
                <div className="flex items-center justify-between mb-2">
                  <span className={`font-semibold text-sm ${categoryColors[i].text}`}>{kat}</span>
                  <span className="text-xs bg-white px-2 py-1 rounded-full font-medium text-gray-600 shadow-sm">
                    {pct}%
                  </span>
                </div>
                <p className={`text-xl font-bold ${categoryColors[i].text}`}>{formatRupiah(sisa)}</p>
                <p className="text-xs text-gray-500 mt-1">Sisa saldo dari {formatRupiah(saldo)}</p>
                <div className="mt-3 bg-white rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-full bg-gradient-to-r ${categoryColors[i].bg} rounded-full transition-all`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Bar Chart */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <h3 className="font-semibold text-gray-700 mb-4">Kas Masuk per Bulan</h3>
          <div className="flex items-end gap-2 h-40">
            {chartMonths.map((month, i) => {
              const total = getTotalBulanan(i);
              const height = total > 0 ? Math.max((total / maxTotal) * 100, 8) : 0;
              return (
                <div key={month} className="flex-1 flex flex-col items-center gap-1">
                  <span className="text-xs font-medium text-gray-600">{formatRupiah(total).replace("Rp", "")}</span>
                  <div className="w-full flex items-end" style={{ height: "100px" }}>
                    <div
                      className={`w-full rounded-t-lg transition-all duration-500 ${
                        total === 0 ? "bg-gray-100" : "bg-gradient-to-t from-blue-600 to-blue-400"
                      }`}
                      style={{ height: `${height}%` }}
                    />
                  </div>
                  <span className="text-xs text-gray-500 truncate w-full text-center">
                    {month.substring(0, 3)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Teknisi List */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
        <h3 className="font-semibold text-gray-700 mb-4">Daftar Teknisi</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {teknisiList.map((t, i) => {
            const colors = ["bg-blue-100 text-blue-700", "bg-purple-100 text-purple-700", "bg-emerald-100 text-emerald-700", "bg-orange-100 text-orange-700", "bg-pink-100 text-pink-700"];
            const color = colors[i % colors.length];
            return (
              <div key={t.id} className="flex flex-col items-center gap-2 p-3 rounded-xl bg-gray-50 border border-gray-100">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${color}`}>
                  {t.nama.charAt(0).toUpperCase()}
                </div>
                <span className="text-sm font-medium text-gray-700 text-center">{t.nama}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
