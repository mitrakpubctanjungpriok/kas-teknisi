import { useState } from "react";
import { MONTHS } from "../types";
import { KasMasukEntry } from "../types";

interface KasMasukProps {
  teknisiList: { id: string; nama: string }[];
  getKasMasuk: (teknisiId: string, bulan: number) => KasMasukEntry | undefined;
  getTotalBulanan: (bulan: number) => number;
  updateKasMasuk: (teknisiId: string, bulan: number, jumlah: number, tidakAdaGC?: boolean) => void;
  addTeknisi: (nama: string) => void;
  removeTeknisi: (id: string) => void;
}

function formatRupiah(amount: number) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(amount);
}

export default function KasMasuk({
  teknisiList,
  getKasMasuk,
  getTotalBulanan,
  updateKasMasuk,
  addTeknisi,
  removeTeknisi,
}: KasMasukProps) {
  const [editCell, setEditCell] = useState<{ teknisiId: string; bulan: number } | null>(null);
  const [editValue, setEditValue] = useState("");
  const [newNama, setNewNama] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const handleCellClick = (teknisiId: string, bulan: number) => {
    const entry = getKasMasuk(teknisiId, bulan);
    setEditCell({ teknisiId, bulan });
    setEditValue(entry && !entry.tidakAdaGC ? String(entry.jumlah) : "");
  };

  const handleSave = () => {
    if (!editCell) return;
    const jumlah = parseInt(editValue) || 0;
    updateKasMasuk(editCell.teknisiId, editCell.bulan, jumlah, false);
    setEditCell(null);
  };

  const handleToggleGC = (teknisiId: string, bulan: number) => {
    const entry = getKasMasuk(teknisiId, bulan);
    const isGC = entry?.tidakAdaGC;
    updateKasMasuk(teknisiId, bulan, 0, !isGC);
  };

  const handleAddTeknisi = () => {
    if (newNama.trim()) {
      addTeknisi(newNama.trim());
      setNewNama("");
      setShowAddForm(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Kas Masuk</h2>
          <p className="text-gray-500 text-sm mt-1">Kelola iuran bulanan setiap teknisi</p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-xl text-sm font-medium transition-all shadow-md shadow-blue-200"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Tambah Teknisi
        </button>
      </div>

      {/* Add Form */}
      {showAddForm && (
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex gap-3">
          <input
            type="text"
            value={newNama}
            onChange={(e) => setNewNama(e.target.value)}
            placeholder="Nama teknisi baru..."
            className="flex-1 px-4 py-2 rounded-xl border border-blue-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
            onKeyDown={(e) => e.key === "Enter" && handleAddTeknisi()}
          />
          <button
            onClick={handleAddTeknisi}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-all"
          >
            Simpan
          </button>
          <button
            onClick={() => setShowAddForm(false)}
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-xl text-sm font-medium transition-all"
          >
            Batal
          </button>
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap gap-3 text-xs">
        <div className="flex items-center gap-1.5">
          <div className="w-4 h-4 rounded bg-blue-100 border border-blue-300"></div>
          <span className="text-gray-600">Klik cell untuk edit nilai</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-4 h-4 rounded bg-amber-400"></div>
          <span className="text-gray-600">Tidak ada GC (klik kanan untuk toggle)</span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-blue-800 to-blue-700 text-white">
                <th className="text-left px-4 py-3.5 font-semibold sticky left-0 bg-blue-800 min-w-[130px]">
                  Teknisi
                </th>
                {MONTHS.map((month) => (
                  <th key={month} className="px-3 py-3.5 font-semibold text-center min-w-[100px]">
                    {month}
                  </th>
                ))}
                <th className="px-3 py-3.5 font-semibold text-center min-w-[80px]">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {teknisiList.map((teknisi, rowIdx) => (
                <tr
                  key={teknisi.id}
                  className={rowIdx % 2 === 0 ? "bg-white" : "bg-gray-50/60"}
                >
                  <td className={`px-4 py-3 font-medium text-gray-800 sticky left-0 ${rowIdx % 2 === 0 ? "bg-white" : "bg-gray-50"} border-r border-gray-100`}>
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold">
                        {teknisi.nama.charAt(0)}
                      </div>
                      {teknisi.nama}
                    </div>
                  </td>
                  {MONTHS.map((_, bulanIdx) => {
                    const entry = getKasMasuk(teknisi.id, bulanIdx);
                    const isEditing = editCell?.teknisiId === teknisi.id && editCell?.bulan === bulanIdx;
                    const isGC = entry?.tidakAdaGC;

                    return (
                      <td
                        key={bulanIdx}
                        className={`px-2 py-2 text-center border-r border-gray-50 cursor-pointer select-none transition-all ${
                          isGC
                            ? "bg-amber-400 text-blue-900 font-semibold"
                            : "hover:bg-blue-50"
                        }`}
                        onClick={() => !isGC && handleCellClick(teknisi.id, bulanIdx)}
                        onContextMenu={(e) => {
                          e.preventDefault();
                          handleToggleGC(teknisi.id, bulanIdx);
                        }}
                      >
                        {isEditing ? (
                          <input
                            autoFocus
                            type="number"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            onBlur={handleSave}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") handleSave();
                              if (e.key === "Escape") setEditCell(null);
                            }}
                            className="w-20 text-center border border-blue-400 rounded-lg px-1 py-0.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                          />
                        ) : isGC ? (
                          <span className="text-xs font-bold rotate-90 inline-block">Tidak ada GC</span>
                        ) : entry && entry.jumlah > 0 ? (
                          <span className="text-gray-700 font-medium">{formatRupiah(entry.jumlah)}</span>
                        ) : (
                          <span className="text-gray-300">—</span>
                        )}
                      </td>
                    );
                  })}
                  <td className="px-2 py-2 text-center">
                    {confirmDelete === teknisi.id ? (
                      <div className="flex gap-1 justify-center">
                        <button
                          onClick={() => {
                            removeTeknisi(teknisi.id);
                            setConfirmDelete(null);
                          }}
                          className="text-xs bg-red-500 text-white px-2 py-1 rounded-lg hover:bg-red-600"
                        >
                          Ya
                        </button>
                        <button
                          onClick={() => setConfirmDelete(null)}
                          className="text-xs bg-gray-200 text-gray-700 px-2 py-1 rounded-lg hover:bg-gray-300"
                        >
                          Batal
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setConfirmDelete(teknisi.id)}
                        className="text-red-400 hover:text-red-600 transition-colors p-1 rounded-lg hover:bg-red-50"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {/* Total Row */}
              <tr className="bg-gradient-to-r from-blue-800 to-blue-700 text-white font-semibold">
                <td className="px-4 py-3 sticky left-0 bg-blue-800">Total Bulanan</td>
                {MONTHS.map((_, i) => (
                  <td key={i} className="px-2 py-3 text-center">
                    {getTotalBulanan(i) > 0 ? (
                      <span className="text-yellow-300">{formatRupiah(getTotalBulanan(i))}</span>
                    ) : (
                      <span className="text-blue-400">—</span>
                    )}
                  </td>
                ))}
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Hint */}
      <p className="text-xs text-gray-400 text-center">
        💡 Klik kiri pada sel untuk mengisi nilai · Klik kanan untuk menandai "Tidak ada GC"
      </p>
    </div>
  );
}
