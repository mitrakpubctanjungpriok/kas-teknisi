import { MONTHS } from "../types";

interface DetailKasProps {
  DETAIL_KATEGORI: string[];
  getDetailKas: (i: number, bulan: number) => number;
  getTotalSaldoKategori: (i: number) => number;
}

function formatRupiah(amount: number) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(amount);
}

const categoryConfig = [
  { color: "text-blue-600", bg: "bg-blue-50", badge: "bg-blue-100 text-blue-700", pct: "40%" },
  { color: "text-purple-600", bg: "bg-purple-50", badge: "bg-purple-100 text-purple-700", pct: "40%" },
  { color: "text-emerald-600", bg: "bg-emerald-50", badge: "bg-emerald-100 text-emerald-700", pct: "20%" },
];

export default function DetailKas({ DETAIL_KATEGORI, getDetailKas, getTotalSaldoKategori }: DetailKasProps) {
  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Detail Kas</h2>
        <p className="text-gray-500 text-sm mt-1">Distribusi kas masuk ke setiap kategori</p>
      </div>

      {/* Info Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {DETAIL_KATEGORI.map((kat, i) => (
          <div key={kat} className={`rounded-2xl p-4 ${categoryConfig[i].bg} border border-gray-100`}>
            <div className="flex items-center justify-between mb-1">
              <span className={`text-sm font-semibold ${categoryConfig[i].color}`}>{kat}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${categoryConfig[i].badge}`}>
                {categoryConfig[i].pct}
              </span>
            </div>
            <p className={`text-2xl font-bold ${categoryConfig[i].color}`}>
              {formatRupiah(getTotalSaldoKategori(i))}
            </p>
            <p className="text-xs text-gray-500 mt-1">Total akumulasi</p>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-semibold text-gray-700">Rincian per Bulan</h3>
          <span className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded-full">
            Otomatis dihitung dari Kas Masuk
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-slate-700 to-slate-600 text-white">
                <th className="text-left px-4 py-3.5 font-semibold sticky left-0 bg-slate-700 min-w-[130px]">
                  Kas Teknisi
                </th>
                {MONTHS.map((month) => (
                  <th key={month} className="px-3 py-3.5 font-semibold text-center min-w-[100px]">
                    {month}
                  </th>
                ))}
                <th className="px-4 py-3.5 font-semibold text-center min-w-[120px] bg-slate-800">
                  Total Saldo
                </th>
              </tr>
            </thead>
            <tbody>
              {DETAIL_KATEGORI.map((kat, katIdx) => (
                <tr key={kat} className={katIdx % 2 === 0 ? "bg-white" : "bg-gray-50/60"}>
                  <td className={`px-4 py-3 font-medium sticky left-0 border-r border-gray-100 ${katIdx % 2 === 0 ? "bg-white" : "bg-gray-50"}`}>
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${
                        katIdx === 0 ? "bg-blue-500" : katIdx === 1 ? "bg-purple-500" : "bg-emerald-500"
                      }`}></span>
                      <span className={categoryConfig[katIdx].color}>{kat}</span>
                    </div>
                  </td>
                  {MONTHS.map((_, bulanIdx) => {
                    const val = getDetailKas(katIdx, bulanIdx);
                    return (
                      <td key={bulanIdx} className="px-2 py-3 text-center border-r border-gray-50">
                        {val > 0 ? (
                          <span className="text-gray-700 font-medium">{formatRupiah(val)}</span>
                        ) : (
                          <span className="text-gray-300">—</span>
                        )}
                      </td>
                    );
                  })}
                  <td className="px-4 py-3 text-center bg-gradient-to-r from-green-50 to-emerald-50">
                    <span className="font-bold text-emerald-700">{formatRupiah(getTotalSaldoKategori(katIdx))}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Note */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex gap-3">
        <svg className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <div className="text-sm text-amber-800">
          <p className="font-semibold mb-1">Catatan Distribusi Kas</p>
          <p className="text-amber-700">
            Setiap bulan, total kas masuk didistribusikan otomatis: <strong>Konsumsi 40%</strong>, <strong>Dana Sosial 40%</strong>, dan <strong>Dana Darurat 20%</strong>.
          </p>
        </div>
      </div>
    </div>
  );
}
